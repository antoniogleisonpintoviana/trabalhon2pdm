package com.example.quiz;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class PerguntasActitivity extends Activity {

   // CheckBox ckb1, ckb2, ckb3, ckb4;

    RadioButton rbResposta1,rbResposta2,rbResposta3,rbResposta4;

    Button btnResponder;
    int respostaDoUsuario;
    int gabarito = 2;
    Integer pontos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perguntas);



        rbResposta1 = (RadioButton)findViewById(R.id.rbResposta1);
        rbResposta2 = (RadioButton)findViewById(R.id.rbResposta2);
        rbResposta3 = (RadioButton)findViewById(R.id.rbResposta3);
        rbResposta4 = (RadioButton)findViewById(R.id.rbResposta4);

        btnResponder = (Button) findViewById(R.id.btnResponder);


        rbResposta1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    respostaDoUsuario = 1;
                }
            }
        });

        btnResponder.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (respostaDoUsuario == gabarito) {
                    pontos++;
                    metodoParaTelaDeAcertou ();

                }

            }
        });





    }

    //metodo para criar novo usuario
    private void metodoParaTelaDeAcertou (){
        Intent intent = new Intent(this, RespostaActivity.class);

        startActivity(intent);
    }


    }
