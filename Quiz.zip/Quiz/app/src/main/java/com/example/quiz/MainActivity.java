package com.example.quiz;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    Button btnLogin, btnNovoUsuario, btnRecuperarSenha, btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        /// Ao clicar no botão login chama a tela principal
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MetodoParalogar();
            }
        });

        /// Ao clicar no botão login chama a tela de criar novo usuario
        btnNovoUsuario = (Button) findViewById(R.id.btnNovoUsuario);
        btnNovoUsuario.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MetodoParaCriarNovoUsuario();
            }
        });

        /// Ao clicar no botão login chama a tela de recuperar senha
        btnRecuperarSenha = (Button) findViewById(R.id.btnRecuperar);
        btnRecuperarSenha.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MetodoParaRecuperarSenha();
            }
        });
    }



        //metodo para logar
        private void MetodoParalogar () {
            Intent intent = new Intent(this, PrincipalActivity.class);

            startActivity(intent);
        }

    //metodo para criar novo usuario
    private void MetodoParaCriarNovoUsuario () {
        Intent intent = new Intent(this, NovoUsuarioActitivity.class);

        startActivity(intent);
    }


    //metodo para recuperar senha
    private void MetodoParaRecuperarSenha () {
        Intent intent = new Intent(this, RecuperarSenhaActitivy.class);

        startActivity(intent);
    }



        ///////////////////////////////////////////////////




















    }







