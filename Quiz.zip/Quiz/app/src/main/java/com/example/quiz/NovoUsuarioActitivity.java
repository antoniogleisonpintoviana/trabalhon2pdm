package com.example.quiz;

import android.app.Activity;
import android.os.Bundle;

public class NovoUsuarioActitivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.novo_usuario);
    }


}
