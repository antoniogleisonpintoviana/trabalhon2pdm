package com.example.quiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PrincipalActivity extends Activity {

    Button btnIniciarJogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);

        btnIniciarJogo = (Button)findViewById(R.id.btnIniciarJogo);


        btnIniciarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MetodoResponsavelPorIrATelaDePerguntas ();

            }
        });
    }

    //metodo para  para ir a tela de perguntas
   private void MetodoResponsavelPorIrATelaDePerguntas () {
        Intent intent = new Intent(this, PerguntasActitivity.class);

        startActivity(intent);
    }


}
